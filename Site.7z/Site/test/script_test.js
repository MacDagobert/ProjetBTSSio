const grilleTest = [
    "+---------------+",
    "|               |",
    "|               |",
    "|               |",
    "|               |",
    "|               |",
    "|               |",
    "|               |",
    "|               |",
    "|               |",
    "|               |",
    "+---------------+"
];

// Récupérer l'élément <pre> pour afficher la grille
const grilleElement = document.getElementById('grille');

// Joindre les lignes en une seule chaîne et l'afficher
grilleElement.textContent = grilleTest.join('\n');

let position = { x: 7, y: 1 }; // Position initiale du #
        
function renderGrille() {
    const grilleElement = document.getElementById('grille');
    const modifiedGrille = grilleTest.map((ligne, index) => {
        if (index === position.y) {
            return ligne.substring(0, position.x) + '#' + ligne.substring(position.x + 1);
        }
        return ligne;
    });
    grilleElement.textContent = modifiedGrille.join('\n');
}

function move(direction) {
    // Calculer la nouvelle position
    if (direction === 'ArrowUp' && position.y > 1) position.y--;
    if (direction === 'ArrowDown' && position.y < 10) position.y++;
    if (direction === 'ArrowLeft' && position.x > 1) position.x--;
    if (direction === 'ArrowRight' && position.x < 15) position.x++;
    renderGrille(); // Re-render la grille
}

// Initialiser la grille
renderGrille();

// Écouter les événements de touche
window.addEventListener('keydown', (event) => {
    move(event.key);
});