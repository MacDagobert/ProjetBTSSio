# Créé par SIO, le 18/09/2024 en Python 3.7

question=("Quel est votre IMC")
print(question)
masse = float(input("Saisir votre masse en Kg: "))
taille = float(input("Saisir votre taille en m: "))
imc = masse/(taille)**2
print(f"Votre imc calculé est de : {round(imc, 2)}")

