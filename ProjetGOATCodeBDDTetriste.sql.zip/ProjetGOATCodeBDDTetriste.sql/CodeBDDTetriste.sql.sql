-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mer. 23 oct. 2024 à 14:32
-- Version du serveur : 8.3.0
-- Version de PHP : 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ttrist`
--

-- --------------------------------------------------------

--
-- Structure de la table `connexion`
--

DROP TABLE IF EXISTS `connexion`;
CREATE TABLE IF NOT EXISTS `connexion` (
  `id_connexion` int NOT NULL AUTO_INCREMENT,
  `id_joueur` int NOT NULL,
  `date_connexion` datetime DEFAULT NULL,
  `status` tinyint DEFAULT '0',
  PRIMARY KEY (`id_connexion`),
  KEY `fk_joueur_connexion` (`id_joueur`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `connexion`
--

INSERT INTO `connexion` (`id_connexion`, `id_joueur`, `date_connexion`, `status`) VALUES
(1, 1, '2024-10-01 14:25:00', 1),
(2, 2, '2024-10-02 15:55:00', 1),
(3, 3, '2024-10-03 18:10:00', 1),
(4, 4, '2024-10-04 19:40:00', 1),
(5, 5, '2024-10-05 20:55:00', 1),
(6, 1, '2024-10-06 10:00:00', 0),
(7, 2, '2024-10-06 11:30:00', 0);

-- --------------------------------------------------------

--
-- Structure de la table `joueurs`
--

DROP TABLE IF EXISTS `joueurs`;
CREATE TABLE IF NOT EXISTS `joueurs` (
  `id_joueur` int NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(50) DEFAULT NULL,
  `mail` varchar(50) DEFAULT NULL,
  `date_inscription` date DEFAULT NULL,
  `password` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id_joueur`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `joueurs`
--

INSERT INTO `joueurs` (`id_joueur`, `pseudo`, `mail`, `date_inscription`, `password`) VALUES
(1, 'playerOne', 'player1@example.com', '2024-01-15', 'password123'),
(2, 'gamerGirl', 'gamergirl@example.com', '2024-02-10', 'passw0rd'),
(3, 'xXEliteXx', 'eliteplayer@example.com', '2024-03-05', 'elitepass!'),
(4, 'noobMaster', 'noobmaster@example.com', '2024-04-12', 'noobmaster42'),
(5, 'proGamer', 'progamerguy@example.com', '2024-05-18', 'propass2024');

-- --------------------------------------------------------

--
-- Structure de la table `partie`
--

DROP TABLE IF EXISTS `partie`;
CREATE TABLE IF NOT EXISTS `partie` (
  `id_partie` bigint NOT NULL AUTO_INCREMENT,
  `date_partie` datetime DEFAULT NULL,
  `temps_partie` time DEFAULT NULL,
  `type_partie` varchar(15) DEFAULT NULL,
  `id_joueur` int NOT NULL,
  PRIMARY KEY (`id_partie`),
  KEY `fk_joueur` (`id_joueur`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `partie`
--

INSERT INTO `partie` (`id_partie`, `date_partie`, `temps_partie`, `type_partie`, `id_joueur`) VALUES
(1, '2024-10-01 14:30:00', '00:45:00', 'solo', 1),
(2, '2024-10-02 16:00:00', '01:10:00', 'multiplayer', 2),
(3, '2024-10-03 18:15:00', '00:35:00', 'solo', 3),
(4, '2024-10-04 19:45:00', '01:20:00', 'tournament', 4),
(5, '2024-10-05 21:00:00', '00:50:00', 'multiplayer', 5);

-- --------------------------------------------------------

--
-- Structure de la table `score`
--

DROP TABLE IF EXISTS `score`;
CREATE TABLE IF NOT EXISTS `score` (
  `id_score` bigint NOT NULL AUTO_INCREMENT,
  `total_points` bigint DEFAULT NULL,
  `niveau_max` bigint DEFAULT NULL,
  `id_partie` bigint NOT NULL,
  PRIMARY KEY (`id_score`),
  KEY `fk_partie` (`id_partie`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `score`
--

INSERT INTO `score` (`id_score`, `total_points`, `niveau_max`, `id_partie`) VALUES
(1, 1500, 10, 1),
(2, 2500, 15, 2),
(3, 1200, 8, 3),
(4, 3200, 20, 4),
(5, 1800, 12, 5);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `ten_best_score`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `ten_best_score`;
CREATE TABLE IF NOT EXISTS `ten_best_score` (
`total_points` bigint
,`pseudo` varchar(50)
,`niveau_max` bigint
);

-- --------------------------------------------------------

--
-- Structure de la vue `ten_best_score`
--
DROP TABLE IF EXISTS `ten_best_score`;

DROP VIEW IF EXISTS `ten_best_score`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ten_best_score`  AS SELECT `s`.`total_points` AS `total_points`, `j`.`pseudo` AS `pseudo`, `s`.`niveau_max` AS `niveau_max` FROM ((`score` `s` join `partie` `p` on((`s`.`id_partie` = `p`.`id_partie`))) join `joueurs` `j` on((`p`.`id_joueur` = `j`.`id_joueur`))) ORDER BY `s`.`total_points` DESC LIMIT 0, 10 ;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `connexion`
--
ALTER TABLE `connexion`
  ADD CONSTRAINT `fk_joueur_connexion` FOREIGN KEY (`id_joueur`) REFERENCES `joueurs` (`id_joueur`) ON DELETE CASCADE;

--
-- Contraintes pour la table `partie`
--
ALTER TABLE `partie`
  ADD CONSTRAINT `fk_joueur` FOREIGN KEY (`id_joueur`) REFERENCES `joueurs` (`id_joueur`) ON DELETE CASCADE;

--
-- Contraintes pour la table `score`
--
ALTER TABLE `score`
  ADD CONSTRAINT `fk_partie` FOREIGN KEY (`id_partie`) REFERENCES `partie` (`id_partie`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
