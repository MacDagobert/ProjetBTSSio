<?php

const MYSQL_HOST = 'localhost';
const MYSQL_PORT = 3306;
const MYSQL_NAME = 'tetriste';
const MYSQL_USER = 'root';
const MYSQL_PASSWORD = '';