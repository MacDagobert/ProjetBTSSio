<div>
    <?php if (isset($_SESSION['LOGGED_USER'])) : ?>
        <?php
        // Check if LOGGED_USER is an array
        if (is_array($_SESSION['LOGGED_USER'])) {
            // Convert the array to a string in a meaningful way
            // For example, join the elements with a space
            $loggedUser = implode(' ', $_SESSION['LOGGED_USER']);
        } else {
            // If it's not an array, use it as is
            $loggedUser = $_SESSION['LOGGED_USER'];
        }
        ?>
        <p>Bienvenue, <?php echo htmlspecialchars($loggedUser); ?></p>
        <li class="nav-item">
            <a class="nav-link" href="logout.php">Déconnexion</a>
        </li>
    <?php endif; ?>
</div>
