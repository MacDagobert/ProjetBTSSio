<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Site/style.css">
    <title>Ttrist</title>
</head>

<body>
<?php if (isset($_SESSION['LOGGED_USER'])) : ?>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Déconnexion</a>
                    </li>
                <?php endif; ?>
    <h1>Bienvenue chez Ttrist</h1>
<?php require once("__DIR__"."/login.php"); ?>
    <div class="button-container">
        <!-- Bouton Se connecter -->
        <button id="btnConnexion" type="button" onclick="window.location.href='connexion.html'">Jouer en mode invité</button>

        <!-- Bouton S'enregistrer -->
        <button type="button" onclick="window.location.href='login.php'">Se connecter / S'enregistrer</button>

    </div>

    <!-- <div class="groupe">
        <img src="../Site/ttrist.jpg" alt="Photo de groupe">
    </div> -->

    <script src="script.js"></script>

</body>

</html>