let grille = [
    "+---------------+",
    "|               |",
    "|               |",
    "|               |",
    "|               |",
    "|               |",
    "|               |",
    "|               |",
    "|               |",
    "|               |",
    "+---------------+"
];

let leZ = []
let leCarre = [["    ", " XX ", " XX ", "    "],
["    ", " XX ", " XX ", "    "],
["    ", " XX ", " XX ", "    "],
["    ", " XX ", " XX ", "    "]
]

let tetrominos = [leZ, leCarre];


let grille1 = [
    "|               |",
    "|      #        |",
    "|               |",
    "|               |",
    "| #  #  ###  ###|",
    "|# ######## ####|",
    "|####### ## ####|",
    "|###### ##### ##|",
    "|########## ####|",
    "+---------------+"
];

let x = 7;
let y = 1;
function grille_dessin(grille) {
    let dessin = "";
    for (const ligne of grille) {
        let laligne = "";
        for (const c of ligne) {
            if (c == ' ') laligne += "&nbsp;";
            else laligne += c;
        }
        dessin = dessin + laligne + "<BR>";
    }
    return dessin;
}

/** 
\fn placerCar
\brief cette fonction place un caractère dans la grille
\param y:la ligne, x: la colonne, c: le caractère
\return néant
**/

let ok = 1;

function placerCar(y, x, c) {
    ligne = grille[y].slice(0, x) + c + grille[y].slice(x + 1);
    return ligne;
}

function placerCar_old(y, x, c) {
    ligne = "|";
    for (let i = 1; i < x; i++) ligne = ligne + grille[y][i];
    ligne = ligne + c;
    for (let i = x + 1; i <= 15; i++) ligne = ligne + grille[y][i];
    ligne = ligne + "|";
    return ligne;
}

document.getElementById("jeu").innerHTML = grille_dessin(grille);

function deteckKeyPressed() { //déplacer avec les touches
    document.addEventListener('keydown', function (event) {
        switch (event.key) {
            case 'ArrowLeft':
                if (grille[y][x - 1] == " ") x--;
                grille[y] = placerCar(y, x + 1, " ");
                grille[y] = placerCar(y, x, "#");
                console.log(x, y);
                document.getElementById("jeu").innerHTML = grille_dessin(grille);
                break;
            case 'ArrowRight':
                if (grille[y][x + 1] == " ") x++;
                grille[y] = placerCar(y, x - 1, " ");
                grille[y] = placerCar(y, x, "#");
                console.log(x, y);
                document.getElementById("jeu").innerHTML = grille_dessin(grille);
                break;
            case 'ArrowUp':
                break;
            case 'ArrowDown':
                // Vérifie si le mouvement vers le bas est possible
                if (grille[y + 1][x] == " ") {
                    // Déplacement vers le bas si l'espace est vide
                    y++;
                    grille[y - 1] = placerCar(y - 1, x, " ");
                    grille[y] = placerCar(y, x, "#");
                    document.getElementById("jeu").innerHTML = grille_dessin(grille);
                } else {
                    // Si le mouvement vers le bas n'est pas possible
                    if (x === 6 && y === 1) {
                        // Si le # est à (7, 1)
                        document.getElementById("gameOverMessage").style.display = 'block'; // Affiche "Game Over"
                        console.log("Game Over affiché"); // Pour déboguer
                    }
                    ok = 0; // Arrête le jeu
                }
                break;

            case 'Escape':
                ok = 0;
                break;
            default:
                break;
        }
    });
}


GAME_SIZE = 100
function clearScreen() {
    //    ctx.clearRect(0, 0, GAME_SIZE, GAME_SIZE);
}

function update() {
    clearScreen();

    if (grille[y + 1][x] == " ") {
        y = y + 1;
        grille[y - 1] = placerCar(y - 1, x, " ");
        grille[y] = placerCar(y, x, "#");
        document.getElementById("jeu").innerHTML = grille_dessin(grille);
    }
    else {
        y = 1;
        x = 7;
        if (grille[y][x] == "#") {

        }
        grille[y] = placerCar(y, x, "#");
        document.getElementById("jeu").innerHTML = grille_dessin(grille);
    }
    if (ok)
        setTimeout(update, 500);
}

function start() {
    deteckKeyPressed();
    update();
}

start();

document.getElementById("gameOverMessage").style.display = 'none'; // Masque "Game Over" au départ

