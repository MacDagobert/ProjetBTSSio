<?php
ini_set('display_errors', 1);  // Activer l'affichage des erreurs
error_reporting(E_ALL);         // Afficher toutes les erreurs

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $pseudo = $_POST['pseudo'];
    $password = $_POST['password'];

    // Vérifier si l'utilisateur existe dans la base de données
    $stmt = $pdo->prepare("SELECT * FROM joueurs WHERE pseudo = ?");
    $stmt->execute([$pseudo]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {  // Vérifier le mot de passe
        // Démarrer une session et enregistrer les informations de l'utilisateur
        session_start();
        $_SESSION['user_id'] = $user['id_joueur'];
        $_SESSION['username'] = $user['pseudo'];

        // Rediriger vers le tableau de bord ou une autre page
        header("Location: dashboard.php");
        exit(); // S'assurer que le script s'arrête après la redirection
    } else {
        echo "Nom d'utilisateur ou mot de passe incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="login.php" method="POST">
        <label for="pseudo">Nom d'utilisateur :</label>
        <input type="text" name="pseudo" id="pseudo" required>
        <label for="password">Mot de passe :</label>
        <input type="password" name="password" id="password" required>
        <button type="submit">Se connecter</button>
    </form>
</body>
</html>
