<?php
ini_set('display_errors', 1);  // Activer l'affichage des erreurs
error_reporting(E_ALL);         // Afficher toutes les erreurs

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Vérifier si le pseudo et le mot de passe sont remplis
    if (empty($_POST['pseudo']) || empty($_POST['password'])) {
        echo "Veuillez remplir tous les champs.";
        exit;
    }

    $pseudo = $_POST['pseudo'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);  // Hachage du mot de passe

    // Vérifier si l'utilisateur existe déjà
    $stmt = $pdo->prepare("SELECT * FROM joueurs WHERE pseudo = ?");
    $stmt->execute([$pseudo]);
    $user = $stmt->fetch();

    if ($user) {
        echo "Ce pseudo est déjà pris. Veuillez en choisir un autre.";
    } else {
        // Insérer l'utilisateur si ce n'est pas déjà pris
        $stmt = $pdo->prepare("INSERT INTO joueurs (pseudo, password) VALUES (?, ?)");
        if ($stmt->execute([$pseudo, $password])) {
            echo "Utilisateur enregistré avec succès ! <a href='login.php'>Se connecter</a>";
        } else {
            echo "Erreur lors de l'enregistrement. Veuillez réessayer.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="register.php" method="POST">
        <label for="pseudo">Nom d'utilisateur :</label>
        <input type="text" name="pseudo" id="pseudo" required>
        <label for="password">Mot de passe :</label>
        <input type="password" name="password" id="password" required>
        <button type="submit">S'inscrire</button>
    </form>
</body>
</html>
