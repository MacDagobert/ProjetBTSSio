<?php
$host = 'localhost';
$db = 'tetriste';
$user = 'root';
$pass = '';

try {
    // Connexion à la base de données avec gestion des erreurs
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    
    // Configuration des attributs PDO pour améliorer la sécurité et la gestion des erreurs
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);  // Récupérer les résultats sous forme de tableau associatif
    
} catch (PDOException $e) {
    // Affichage d'un message d'erreur si la connexion échoue
    die("Erreur de connexion : " . $e->getMessage());
}
?>
