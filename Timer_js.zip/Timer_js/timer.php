<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="witdh">
    <title>Timer</title>
    <p><script>
        function wait(duration) {
            const t = Date.now
            while (Date.now() - t < duration) { }
        }

        let A = 0
        let secondes = A
        let minutes = 0
        let heures = 0



        // wait(500)

        setInterval(() => {
            A++
            if (A > 59) {
                minutes++
                A = 0;
            }
            secondes = A
            console.log("Vous jouez depuis minutes:", minutes, "et", secondes , "secondes")

        }, 1000)



    </script> </p>
</head>